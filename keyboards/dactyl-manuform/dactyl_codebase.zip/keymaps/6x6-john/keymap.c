#include "dactyl-manuform.h"
#include "action_layer.h"
#include "eeconfig.h"

extern keymap_config_t keymap_config;

// Each layer gets a name for readability, which is then used in the keymap matrix below.
// The underscores don't mean anything - you can have a layer called STUFF or any other name.
// Layer names don't all need to be of the same length, obviously, and you can also skip them
// entirely and just use numbers.
#define _DEFAULT 0
#define _NUMBER   1
#define _NAVIGATION   2

// Fillers to make layering more clear
#define _______ KC_TRNS
#define XXXXXXX KC_NO

const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
[_DEFAULT] = KEYMAP_6x6(
  // left hand
   KC_F1,    KC_F2,   KC_F3,   KC_F4,  KC_F5,  KC_F6, 
   KC_1,     KC_2,    KC_3,    KC_4,   KC_5,   KC_6, 
   KC_TAB,   KC_Q,    KC_W,    KC_F,   KC_P,   KC_G,
   KC_LCTL,  KC_A,    KC_R,    KC_S,   KC_T,   KC_D,
   LSFT_T(KC_CAPS),  KC_Z,    KC_X,    KC_C,   KC_V,   KC_B,
                       KC_BSPC, KC_DEL,
                            KC_SPC, KC_ENTER, 
                               TT(_NUMBER), TT(_NAVIGATION),
                               KC_LCTRL, KC_LGUI,
        // right hand
    KC_F7,   KC_F8,  KC_F9,   KC_F10,  KC_F11,  KC_F12,
    KC_7,    KC_8,   KC_9,    KC_0,    KC_F11,  KC_F12,
    KC_J,    KC_L,   KC_U,    KC_Y,    KC_LBRC, KC_RBRC,
    KC_H,    KC_N,   KC_E,    KC_I,    KC_O,    KC_QUOT, 
    KC_K,    KC_M,   KC_COMM, KC_DOT,  KC_SLSH, RSFT_T(KC_CAPS),
                     KC_BSPC, KC_DEL,
                 KC_SPC, KC_ENTER, 
        TT(_NUMBER), TT(_NAVIGATION),
        KC_RGUI, KC_RCTRL),
[_NUMBER] = KEYMAP_6x6(
  // left hand
    _______,  _______,  _______,  _______,  _______,  _______, 
    _______,  _______,  _______,  _______,  _______,  _______, 
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  _______,  _______,  _______,  _______,  _______,
                        _______,  _______,
                              _______, _______, 
                                   _______, _______,
                                   _______, _______,
        // right hand
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  KC_PDOT, KC_PSLS,   KC_PAST,  KC_0,     KC_MINS,
    _______,  KC_7,    KC_8,      KC_9,     KC_PPLS,  KC_EQL,
    _______,  KC_4,    KC_5,      KC_6,     KC_0,     KC_PENT, 
    _______,  KC_1,    KC_2,      KC_3,     KC_PMNS,  KC_DEL,
                       _______,  _______,
                  _______, _______, 
        _______, _______,
        _______, _______),
[_NAVIGATION] = KEYMAP_6x6(
  // left hand
    _______,  _______,  _______,  _______,  _______,  _______, 
    _______,  _______,  _______,  _______,  _______,  _______, 
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  _______,  _______,  _______,  _______,  _______,
                        _______,  _______,
                             _______, _______, 
                                  _______, _______,
                                  _______, _______,
        // right hand
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  _______,  _______,  _______,  _______,  _______,
    _______,  KC_HOME,  KC_PGDN,  KC_PGUP,  KC_END,   _______,
    _______,  KC_LEFT,  KC_DOWN,  KC_UP,    KC_RGHT,  _______, 
    _______,  KC_MS_L,  KC_MS_D,  KC_MS_U,  KC_MS_R,  _______,
                       _______,  _______,
                  KC_BTN1, KC_BTN2, 
        _______, _______,
        _______, _______),
};



void persistant_default_layer_set(uint16_t default_layer) {
  eeconfig_update_default_layer(default_layer);
  default_layer_set(default_layer);
}
